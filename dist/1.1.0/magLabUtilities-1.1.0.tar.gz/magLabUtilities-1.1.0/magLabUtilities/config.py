#!python3

import numpy as np

class Constants:
    # List of constants
    kToC = 273.15
    oeToApm = 79.5774715