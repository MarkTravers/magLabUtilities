#!python3

class Signal:
    def __init__(self, data):
        self.data = data
        self.